#include <pgmspace.h>
const uint16_t animHack[] PROGMEM = {
0x1161, 
0x0203, 
0x238c, 
0x6595, 
0x9ebc, 
0xffff
};