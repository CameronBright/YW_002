#ifndef __BUZZER_H
#define __BUZZER_H

void playSong(bool bell);
extern int songCount;

#endif
